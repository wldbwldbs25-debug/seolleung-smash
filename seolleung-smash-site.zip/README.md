# SEOLLEUNG SMASH 3D

정적 웹사이트 배포용 파일입니다.

## GitHub Pages 배포
1. GitHub에서 새 공개 저장소(repository)를 만듭니다.
2. 이 폴더의 `index.html`을 저장소 최상위(root)에 업로드합니다.
3. 저장소의 Settings → Pages로 이동합니다.
4. Build and deployment에서 `Deploy from a branch`를 선택합니다.
5. Branch를 `main`, 폴더를 `/(root)`로 선택하고 Save를 누릅니다.
6. 잠시 후 Pages 화면에 표시되는 사이트 주소로 접속합니다.

게임은 Three.js를 CDN에서 불러오므로 플레이할 때 인터넷 연결이 필요합니다.
